let img; 
let img2;
let img3;

function preload() {
  img = loadImage('assets/moonwalk.jpg'); // Load the image
  img2 = loadImage('assets/car.jpg');
  img3 = loadImage('assets/smile.png');
}

function setup() {
  createCanvas(720, 400);
}

function draw() {
  image(img, 0, 0);
  tint(255, 50);
  image(img3,0,0,720,400);
  tint(255);
  if (mouseIsPressed) {
    stroke(255);
    image(img2, mouseX-25, mouseY-25, 50, 50);
  } 
  fill(255);
  textFont('Helvetica');
  let s = 'Hello Teacher!';
  let sWidth = textWidth(s);
  text(s, 0, 10);
  line(sWidth, 20, sWidth, 20);
}

