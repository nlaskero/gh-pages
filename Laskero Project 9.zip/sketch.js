var song;
let osc, fft;

function preload(){
 song = loadSound('audio/audio.mp3');
}

function setup() {
  createCanvas(750, 250);
  song.play();
  song.setVolume(0.5);
  
  osc = new p5.TriOsc(); 
  osc.amp(0.01);
  
  fft = new p5.FFT();
  osc.start();
}

function draw() {
  background(220);
  
  let waveform = fft.waveform(); 
  beginShape();
  strokeWeight(5);
  for (let i = 0; i < waveform.length; i++) {
    let x = map(i, 0, waveform.length, 0, width);
    let y = map(waveform[i], -1, 1, height, 0);
    vertex(x, y);
  }
  endShape();
}

function mousePressed() {
  if (song.isPlaying()) {
    song.pause();
  } else {
    song.play(); 
  }
}