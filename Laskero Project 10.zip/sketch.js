let playing = false;
let coke;
let code;
let fan;
let button;

function setup() {
  coke = createVideo(['assets/coke.mov']);//loads videos
  code = createVideo(['assets/code.mov']);
  fan = createVideo(['assets/fan.mov']);
  coke.size(250,250);//video size
  code.size(250,250);
  fan.size(250,250);
  button = createButton('play');//play/pause button
  button.mousePressed(toggleVid); // calls function
}


function toggleVid() {
  if (playing) {
    coke.pause();
    code.pause();
    fan.pause();
    button.html('play');
  } else {
    coke.loop();
    code.loop();
    fan.loop();
    coke.volume(0);//mutes audio
    code.volume(0);
    fan.volume(0);
    button.html('pause');
  }
  playing = !playing;
}

