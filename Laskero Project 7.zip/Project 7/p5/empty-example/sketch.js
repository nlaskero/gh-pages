let one = [];
let two = [];
let t = true;
let fr = 10;

function setup() {
  createCanvas(400, 400);
  frameRate(fr);
}

function random1(){
	for (var i = 0; i <= 10; i++) {
		let x = random(180,220);
		let x1 = random(335,370)
		one[i] = round(x);
		two[i] = round(x1);
		print(one);
	}
}

function draw() {
  background(13,10,5);
  random1();
  one[0] = mouseX;
  two[0] = mouseY
  noStroke();
  
  fill(14,127,23);//green hills
  circle(50,500,300);
  circle(200,500,300);
  circle(350,500,300);
  fill(196,116,6);//pumpkin
  circle(200,300,200);
  fill(0);//eyes mouth nose
  quad(125, 315, 200, 385, 275, 315, 200, 340);
  rect(150,250,25,25);
  rect(225,250,25,25);
  triangle(185,315,200,290,215,315);
  fill(96,57,5);//stump
  rect(195,202,14,-35);
  light();

}

	function light(){
		for (var i = 1; i <= 10; i++) {
			fill(235,35,7);
			triangle(200,385,one[i],two[i],one[i-1],two[i-1]);
		}

	}